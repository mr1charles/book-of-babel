import test from 'node:test'; import assert from 'node:assert/strict';
import * as C from '../core.js';
const run = (w, n, chunk=137) => { const e = new C.Engine(w); let left=n; while(left>0){ const c=Math.min(chunk,left); e.tick(c); left-=c;} return e; };
test('deterministic: same seed same pages regardless of tick chunking', () => {
  const a = run(1234, 30000, 137), b = run(1234, 30000, 1000);
  const pa = a.drain().pages, pb = b.drain().pages;
  assert.ok(pa.length > 5); assert.deepEqual(pa.map(p=>p.text), pb.map(p=>p.text));
});
test('page text reproduces from seed + event range', () => {
  const e = run(99, 20000); const p = e.drain().pages[2];
  const spec = C.pageSpec(99, p.idx); let t=''; for (let n=p.startSeq;n<=p.endSeq;n++) t+=C.charAt(spec.mode,spec.seed,n);
  assert.equal(t, p.text); assert.equal(p.count, spec.cap); assert.equal(p.endSeq-p.startSeq+1, p.count);
});
test('pages are contiguous and cover every event once', () => {
  const e = run(7, 40000); const ps = e.drain().pages;
  for (let i=1;i<ps.length;i++) assert.equal(ps[i].startSeq, ps[i-1].endSeq+1);
  assert.equal(ps[0].startSeq, 0);
});
test('boards fill to capacity then a new board starts; board reproducible', () => {
  const e = run(5, 20000); const bs = e.drain().boards; assert.ok(bs.length>=2);
  const b = bs[0], spec = C.boardSpec(5, b.idx);
  assert.equal(b.count, b.w*b.h); assert.deepEqual([...C.paintBoard(spec,b.startSeq,b.count)], [...b.rgba]);
  assert.equal(bs[1].startSeq, b.endSeq+1);
});
test('ledger chain verifies and detects tampering', async () => {
  const e = run(3, 5000); let prev='GENESIS', n=0, ents=[];
  for (let i=0;i<3;i++){ e.tick(10); const d=e.drain(); const en=await C.makeLedgerEntry(n++,prev,3,d); prev=en.hash; ents.push(en); }
  assert.equal((await C.verifyLedger(ents)).ok, true);
  const bad = structuredClone(ents); bad[1].ticks[0][2] += 1;
  assert.equal((await C.verifyLedger(bad)).ok, false);
});
test('resume from saved state continues identically', () => {
  const a = run(11, 12345); const st = structuredClone(a.s); const b = new C.Engine(11, st);
  a.tick(5000); b.tick(5000); a.drain(); b.drain();
  assert.equal(a.chars.join(''), b.chars.join('')); assert.deepEqual([...a.px],[...b.px]);
});
test('signature filter never rejects a true substring', () => {
  const e = run(21, 30000); for (const p of e.drain().pages.slice(0,20)) { const sig=C.sigOf(p.text); const q=p.text.slice(10,20); assert.ok(C.sigMayContain(sig,q)); }
});
test('possibility maths is exact BigInt', () => {
  const r = C.possibility('abc', 1000); assert.equal(r[0].space, 29n**3n);
  assert.equal(C.possibility('Hello!', 1).length, 0 + C.possibility('Hello!',1).length);
});
