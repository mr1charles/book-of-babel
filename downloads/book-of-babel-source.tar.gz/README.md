# The Book of Babel

One **Atom Second** = one recorded generation event = one character on a page + one pixel on a board.
Every output is a pure function of (world seed, event number), so anything archived can be replayed and re-verified exactly.

| Platform | How | Status |
|---|---|---|
| Web / PWA | `cd web && python3 -m http.server 8801` → http://localhost:8801 | Built, tested in Chrome |
| Linux | `./babel-linux` (app window) · `.desktop` entry installed | Built, launcher not GUI-tested beyond Chrome |
| Android | `dist/BookOfBabel-debug.apk` (Capacitor, debug-signed) | APK builds; **not run on a device/emulator** |
| iOS | `android-app/ios` Xcode project (Capacitor) | **Generated only. Needs a Mac + Xcode to build/sign; untested** |
| AI agents | `node babel-mcp.mjs` (HTTP :8803/mcp) or `claude mcp add babel -- node ~/babel/babel-mcp.mjs --stdio`; switch on *Allow AI agents* in The Origin | Tested over HTTP |

iOS: `cd android-app && npx cap open ios`, set your signing team, run. Mobile builds keep their own separate archive (no sync yet) and cannot reach the desktop MCP bridge.

Tests: `cd web && node --test tests/`.

## Honest limits
- Not built: Mathematics/Science/DNA/Code/Audio/Video engines, semantic search, cross-device sync, accounts, backup *import*, native SwiftUI/Compose apps (mobile = Capacitor wrapper of the web app).
- Generation runs only while the app is open.
- Search is exact substring over archived pages (signature-filtered); a long sentence will almost never be found — the Oracle then shows the real odds instead.
- The ledger hash-chain detects corruption/edits, not a full rewrite.
